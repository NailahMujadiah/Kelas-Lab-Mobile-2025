package com.example.praktikum1;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private TextView tvName, tvUsername, tvBio, tvWebsite;
    private ImageView imgProfile, imgHeader;
    private Button editButton;
    private String defaultName, defaultUsername, defaultBio, defaultWebsite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tvName = findViewById(R.id.tvName);
        tvUsername = findViewById(R.id.tvUsername);
        tvBio = findViewById(R.id.tvBio);
        tvWebsite = findViewById(R.id.tvWebsite);
        imgProfile = findViewById(R.id.imgProfile);
        imgHeader = findViewById(R.id.header);
        editButton = findViewById(R.id.editbutton);

        defaultName = getString(R.string.name);
        defaultUsername = getString(R.string.username);
        defaultBio = getString(R.string.bio);
        defaultWebsite = getString(R.string.website);

        tvName.setText(defaultName);
        tvUsername.setText(defaultUsername);
        tvBio.setText(defaultBio);
        tvWebsite.setText(defaultWebsite);
        imgProfile.setImageResource(R.drawable.wonyoung);
        imgHeader.setImageResource(R.drawable.header);

        editButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, EditProfileActivity.class);
            intent.putExtra("name", tvName.getText().toString());
            intent.putExtra("username", tvUsername.getText().toString());
            intent.putExtra("bio", tvBio.getText().toString());
            intent.putExtra("website", tvWebsite.getText().toString());
            startActivityForResult(intent, 1);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            UserProfile user = data.getParcelableExtra("user_profile");

            if (user != null) {
                tvName.setText(user.getName() != null && !user.getName().isEmpty() ? user.getName() : defaultName);
                tvUsername.setText(user.getUsername() != null && !user.getUsername().isEmpty() ? user.getUsername() : defaultUsername);
                tvBio.setText(user.getBio() != null && !user.getBio().isEmpty() ? user.getBio() : defaultBio);
                tvWebsite.setText(user.getWebsite() != null && !user.getWebsite().isEmpty() ? user.getWebsite() : defaultWebsite);


                if (user.getProfileImageUri() != null && !user.getProfileImageUri().isEmpty()) {
                    imgProfile.setImageURI(Uri.parse(user.getProfileImageUri()));
                } else {
                    imgProfile.setImageResource(R.drawable.wonyoung);
                }

                if (user.getHeaderImageUri() != null && !user.getHeaderImageUri().isEmpty()) {
                    imgHeader.setImageURI(Uri.parse(user.getHeaderImageUri()));
                } else {
                    imgHeader.setImageResource(R.drawable.header);
                }
            } else {
                tvName.setText(defaultName);
                tvUsername.setText(defaultUsername);
                tvBio.setText(defaultBio);
                tvWebsite.setText(defaultWebsite);
                imgProfile.setImageResource(R.drawable.wonyoung);
                imgHeader.setImageResource(R.drawable.header);
            }
        }
    }
}