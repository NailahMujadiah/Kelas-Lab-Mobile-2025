package com.example.praktikum1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class EditProfileActivity extends AppCompatActivity {
    private EditText etName, etUsername, etBio, etWebsite;
    private ImageView imgProfile, imgHeader;
    private Button saveBtn;
    private ImageButton EditProfile, EditHeader;

    private static final int PICK_PROFILE_IMAGE = 101;
    private static final int PICK_HEADER_IMAGE = 102;

    private Uri profileImageUri = null;
    private Uri headerImageUri = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_profile);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etName = findViewById(R.id.etName);
        etUsername = findViewById(R.id.etUsername);
        etBio = findViewById(R.id.etBio);
        etWebsite = findViewById(R.id.etWebsite);
        imgProfile = findViewById(R.id.imgProfile);
        imgHeader = findViewById(R.id.imgheader);
        saveBtn = findViewById(R.id.savebtn);
        EditProfile = findViewById(R.id.EditProfile);
        EditHeader = findViewById(R.id.EditHeader);

        Intent intent = getIntent();
        String defaultName = intent.getStringExtra("name") != null ? intent.getStringExtra("name") : getString(R.string.name);
        String defaultUsername = intent.getStringExtra("username") != null ? intent.getStringExtra("username") : getString(R.string.username);
        String defaultBio = intent.getStringExtra("bio") != null ? intent.getStringExtra("bio") : getString(R.string.bio);
        String defaultWebsite = intent.getStringExtra("website") != null ? intent.getStringExtra("website") : getString(R.string.website);

        etName.setText(defaultName);
        etUsername.setText(defaultUsername);
        etBio.setText(defaultBio);
        etWebsite.setText(defaultWebsite);

        imgProfile.setImageResource(R.drawable.wonyoung);
        imgHeader.setImageResource(R.drawable.header);

        ImageButton backButton = findViewById(R.id.Arrow);
        backButton.setOnClickListener(v -> {
            Intent resultIntent = new Intent();
            setResult(RESULT_CANCELED, resultIntent);
            finish();
        });

        EditProfile.setOnClickListener(v -> {
            Intent pickProfile = new Intent(Intent.ACTION_PICK);
            pickProfile.setType("image/*");
            startActivityForResult(pickProfile, PICK_PROFILE_IMAGE);
        });

        EditHeader.setOnClickListener(v -> {
            Intent pickHeader = new Intent(Intent.ACTION_PICK);
            pickHeader.setType("image/*");
            startActivityForResult(pickHeader, PICK_HEADER_IMAGE);
        });

        saveBtn.setOnClickListener(v -> {
            String newName = etName.getText() != null ? etName.getText().toString().trim() : "";
            String newUsername = etUsername.getText() != null ? etUsername.getText().toString().trim() : "";
            String newBio = etBio.getText() != null ? etBio.getText().toString().trim() : "";
            String newWebsite = etWebsite.getText() != null ? etWebsite.getText().toString().trim() : "";

            if (newName.isEmpty()) {
                Toast.makeText(EditProfileActivity.this, "Nama tidak boleh kosong", Toast.LENGTH_SHORT).show();
                return;
            }
            if (newUsername.isEmpty()) {
                Toast.makeText(EditProfileActivity.this, "Username tidak boleh kosong", Toast.LENGTH_SHORT).show();
                return;
            }

            if (newBio.isEmpty()) {
                newBio = getString(R.string.bio);
            }
            if (newWebsite.isEmpty()) {
                newWebsite = getString(R.string.website);
            }

            String newProfileImage = profileImageUri != null ? profileImageUri.toString() : "";
            String newHeaderImage = headerImageUri != null ? headerImageUri.toString() : "";

            UserProfile userProfile = new UserProfile(
                    newName, newUsername, newBio, newWebsite,
                    newProfileImage, newHeaderImage
            );

            Intent resultIntent = new Intent();
            resultIntent.putExtra("user_profile", userProfile);
            setResult(RESULT_OK, resultIntent);
            finish();
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && data != null) {
            Uri selectedImg = data.getData();
            if (requestCode == PICK_PROFILE_IMAGE) {
                profileImageUri = selectedImg;
                imgProfile.setImageURI(profileImageUri);
            } else if (requestCode == PICK_HEADER_IMAGE) {
                headerImageUri = selectedImg;
                imgHeader.setImageURI(headerImageUri);
            }
        } else {
            if (requestCode == PICK_PROFILE_IMAGE) {
                profileImageUri = null;
                imgProfile.setImageResource(R.drawable.wonyoung);
            } else if (requestCode == PICK_HEADER_IMAGE) {
                headerImageUri = null;
                imgHeader.setImageResource(R.drawable.header);
            }
        }
    }
}