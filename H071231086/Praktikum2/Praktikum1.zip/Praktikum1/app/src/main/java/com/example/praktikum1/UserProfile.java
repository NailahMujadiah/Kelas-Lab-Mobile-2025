package com.example.praktikum1;

import android.os.Parcel;
import android.os.Parcelable;

public class UserProfile implements Parcelable {
    private String name;
    private String username;
    private String bio;
    private String website;
    private String profileImageUri;
    private String headerImageUri;

    public UserProfile(String name, String username, String bio, String website,
                       String profileImageUri, String headerImageUri) {
        this.name = name;
        this.username = username;
        this.bio = bio;
        this.website = website;
        this.profileImageUri = profileImageUri;
        this.headerImageUri = headerImageUri;
    }

    protected UserProfile(Parcel in) {
        name = in.readString();
        username = in.readString();
        bio = in.readString();
        website = in.readString();
        profileImageUri = in.readString();
        headerImageUri = in.readString();
    }

    public static final Creator<UserProfile> CREATOR = new Creator<UserProfile>() {
        @Override
        public UserProfile createFromParcel(Parcel in) {
            return new UserProfile(in);
        }

        @Override
        public UserProfile[] newArray(int size) {
            return new UserProfile[size];
        }
    };

    // Getter
    public String getName() {
        return name;
    }

    public String getUsername() {
        return username;
    }

    public String getBio() {
        return bio;
    }

    public String getWebsite() {
        return website;
    }

    public String getProfileImageUri() {
        return profileImageUri;
    }

    public String getHeaderImageUri() {
        return headerImageUri;
    }

    // Setter
    public void setName(String name) {
        this.name = name;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public void setProfileImageUri(String profileImageUri) {
        this.profileImageUri = profileImageUri;
    }

    public void setHeaderImageUri(String headerImageUri) {
        this.headerImageUri = headerImageUri;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(username);
        dest.writeString(bio);
        dest.writeString(website);
        dest.writeString(profileImageUri);
        dest.writeString(headerImageUri);
    }

    @Override
    public int describeContents() {
        return 0;
    }
}
